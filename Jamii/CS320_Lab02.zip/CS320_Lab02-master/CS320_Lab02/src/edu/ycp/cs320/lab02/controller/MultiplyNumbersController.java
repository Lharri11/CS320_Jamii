package edu.ycp.cs320.lab02.controller;

public class MultiplyNumbersController {
	public Double multiply(Double first, Double second) {
		return first * second;
	}
}
