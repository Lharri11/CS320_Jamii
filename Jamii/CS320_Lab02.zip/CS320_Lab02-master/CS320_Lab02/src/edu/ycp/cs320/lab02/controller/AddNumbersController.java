package edu.ycp.cs320.lab02.controller;

public class AddNumbersController {
	public Double add(Double first, Double second) {
		return first + second;
	}
}
